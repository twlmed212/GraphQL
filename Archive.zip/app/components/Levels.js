export const LevelTitles = [
    "Aspiring developer",
    "Beginner developer",
    "Apprentice developer",
    "Assistant developer",
    "Basic developer",
    "Junior developer",
    "Full-Stack developer"
]
